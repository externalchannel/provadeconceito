ace.define("ace/snippets/lucene",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="lucene"});                (function() {
                    ace.require(["ace/snippets/lucene"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            