ace.define("ace/snippets/batchfile",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="batchfile"});                (function() {
                    ace.require(["ace/snippets/batchfile"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            