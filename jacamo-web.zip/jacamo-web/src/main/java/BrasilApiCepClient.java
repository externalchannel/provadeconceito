import cartago.Artifact;
import cartago.OPERATION;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class BrasilApiCepClient extends Artifact {

    @OPERATION
    public void consultarCep(String cep) {
        try {
            String cepLimpo = cep.replaceAll("\\D", "");

            if (!cepLimpo.matches("\\d{8}")) {
                signal("cep_erro", "CEP inválido. Use 8 dígitos.");
                return;
            }

            String endpoint = "https://brasilapi.com.br/api/cep/v1/" + cepLimpo;
            URL url = new URL(endpoint);

            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);

            int status = con.getResponseCode();

            if (status != 200) {
                signal("cep_erro", "HTTP " + status + " ao consultar a API.");
                return;
            }

            BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8)
            );

            StringBuilder resposta = new StringBuilder();
            String linha;

            while ((linha = in.readLine()) != null) {
                resposta.append(linha);
            }

            in.close();
            con.disconnect();

            String json = resposta.toString();

            String estado = extrair(json, "state");

            if (estado == null || estado.isBlank()) {
                signal("cep_erro", "Não foi possível extrair o estado da resposta.");
                return;
            }

            signal("cep_resultado", cepLimpo, estado);

        } catch (Exception e) {
            signal("cep_erro", e.getMessage());
        }
    }

    private String extrair(String json, String chave) {
        String alvo = "\"" + chave + "\":";
        int inicio = json.indexOf(alvo);

        if (inicio == -1) {
            return "";
        }

        inicio = json.indexOf("\"", inicio + alvo.length());
        if (inicio == -1) {
            return "";
        }

        int fim = json.indexOf("\"", inicio + 1);
        if (fim == -1) {
            return "";
        }

        return json.substring(inicio + 1, fim);
    }
}
