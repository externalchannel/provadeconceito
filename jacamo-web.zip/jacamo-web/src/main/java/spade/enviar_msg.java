package spade;

import jason.asSemantics.*;
import jason.asSyntax.*;
import java.net.URI;
import java.net.http.*;
import java.net.http.HttpRequest.BodyPublishers;

public class enviar_msg extends DefaultInternalAction {

    @Override
    public Object execute(TransitionSystem ts, Unifier un, Term[] args) throws Exception {

        String performativa = ((StringTerm) args[0]).getString();
        String json;

        // CFP envia CEP + Estado como campos separados (Opção A)
        // Demais performativas (accept_proposal, inform) mantêm o campo content
        if (args.length == 3) {
            String cep    = ((StringTerm) args[1]).getString();
            String estado = ((StringTerm) args[2]).getString();
            json = "{"
                + "\"performative\": \"" + performativa + "\","
                + "\"cep\": \""          + cep          + "\","
                + "\"estado\": \""       + estado        + "\""
                + "}";
        } else {
            String conteudo = ((StringTerm) args[1]).getString();
            json = "{"
                + "\"performative\": \"" + performativa + "\","
                + "\"content\": \""      + conteudo     + "\""
                + "}";
        }

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("http://localhost:5000/inbox_spade"))
            .header("Content-Type", "application/json")
            .POST(BodyPublishers.ofString(json))
            .build();

        // sendAsync — não trava o ciclo BDI do agente
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        return true;
    }
}
